<nav class="navbar1">
    <a class="navbar-brand" href="#">
        <img src="../upload/logo4.gif" class=" logo" alt="">
    </a>

</nav>